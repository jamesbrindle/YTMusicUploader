from ytmusicapi import YTMusic
ytmusic = YTMusic('headers_auth.json')

search_results = ytmusic.get_library_upload_songs(1) 

print(search_results)